import java.util.*;

class hash {
    public static void main(String args[]) {
        Hashtable<Integer, Boolean> h_1 = new Hashtable<>();
        Hashtable<Integer, Boolean> h_2 = new Hashtable<Integer, Boolean>();
        h_1.put(1, true );
        h_1.put(2, false);
        h_1.put(3, false);

        h_2.put(4, true);
        h_2.put(5, true);
        h_2.put(6, false);

        System.out.println("Mappings of ht1 : " + h_1);
        System.out.println("Mappings of ht2 : " + h_2);
    }
}

